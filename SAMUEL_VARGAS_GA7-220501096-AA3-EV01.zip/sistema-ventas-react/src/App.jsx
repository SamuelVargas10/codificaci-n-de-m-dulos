
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ProductosList from './components/ProductosList';
import ProductosForm from './components/ProductosForm';
import InventarioList from './components/InventarioList';
import InventarioForm from './components/InventarioForm';
import ProveedoresList from './components/ProveedoresList';
import ProveedoresForm from './components/ProveedoresForm';
import ClientesList from './components/ClientesList';
import ClientesForm from './components/ClientesForm';
import FacturasList from './components/FacturasList';
import FacturasForm from './components/FacturasForm';
import DetallesfacturaList from './components/DetallesfacturaList';
import DetallesfacturaForm from './components/DetallesfacturaForm';
import VentasList from './components/VentasList';
import VentasForm from './components/VentasForm';

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/productos" element={<ProductosList />} />
      <Route path="/productos/nuevo" element={<ProductosForm />} />
      <Route path="/productos/editar/:id" element={<ProductosForm />} />
      <Route path="/inventario" element={<InventarioList />} />
      <Route path="/inventario/nuevo" element={<InventarioForm />} />
      <Route path="/inventario/editar/:id" element={<InventarioForm />} />
      <Route path="/proveedores" element={<ProveedoresList />} />
      <Route path="/proveedores/nuevo" element={<ProveedoresForm />} />
      <Route path="/proveedores/editar/:id" element={<ProveedoresForm />} />
      <Route path="/clientes" element={<ClientesList />} />
      <Route path="/clientes/nuevo" element={<ClientesForm />} />
      <Route path="/clientes/editar/:id" element={<ClientesForm />} />
      <Route path="/facturas" element={<FacturasList />} />
      <Route path="/facturas/nuevo" element={<FacturasForm />} />
      <Route path="/facturas/editar/:id" element={<FacturasForm />} />
      <Route path="/detallesFactura" element={<DetallesfacturaList />} />
      <Route path="/detallesFactura/nuevo" element={<DetallesfacturaForm />} />
      <Route path="/detallesFactura/editar/:id" element={<DetallesfacturaForm />} />
      <Route path="/ventas" element={<VentasList />} />
      <Route path="/ventas/nuevo" element={<VentasForm />} />
      <Route path="/ventas/editar/:id" element={<VentasForm />} />
    </Routes>
  </BrowserRouter>
);

export default App;
