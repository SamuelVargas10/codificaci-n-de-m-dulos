
import React, { useState, useEffect } from 'react';
import * as API from '../api/proveedores';
import { useNavigate, useParams } from 'react-router-dom';

const ProveedoresForm = () => {
  const [formData, setFormData] = useState({});
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      API.getById(id).then(res => setFormData(res.data));
    }
  }, [id]);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    id ? await API.update(id, formData) : await API.create(formData);
    navigate('/proveedores');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{id ? 'Editar' : 'Nuevo'} Proveedores</h2>
      <input name="nombre" onChange={handleChange} value={formData.nombre || ''} placeholder="Nombre" />
      <button type="submit">Guardar</button>
    </form>
  );
};

export default ProveedoresForm;
