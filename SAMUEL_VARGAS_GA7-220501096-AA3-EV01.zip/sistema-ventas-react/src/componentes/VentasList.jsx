
import React, { useEffect, useState } from 'react';
import * as API from '../api/ventas';
import { Link } from 'react-router-dom';

const VentasList = () => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    API.getAll().then(res => setItems(res.data));
  }, []);

  const handleDelete = async (id) => {
    await API.remove(id);
    const res = await API.getAll();
    setItems(res.data);
  };

  return (
    <div>
      <h2>Listado de Ventas</h2>
      <Link to="/ventas/nuevo">Agregar</Link>
      <ul>
        {items.map(item => (
          <li key={item.id}>
            {JSON.stringify(item)}
            <Link to={`/ventas/editar/${item.id}`}>Editar</Link>
            <button onClick={() => handleDelete(item.id)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default VentasList;
